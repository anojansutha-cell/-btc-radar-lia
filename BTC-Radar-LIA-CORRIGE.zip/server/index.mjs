import 'dotenv/config';
import express from 'express';
import path from 'node:path';
import fs from 'node:fs';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import OpenAI from 'openai';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
app.use(express.json({ limit: '100kb' }));
app.use(express.static(path.join(__dirname, '..', 'public')));

const DB = path.resolve(__dirname, '..', process.env.DB_FILE || './data/db.json');
fs.mkdirSync(path.dirname(DB), { recursive: true });
if (!fs.existsSync(DB)) fs.writeFileSync(DB, JSON.stringify({ predictions: [], alerts: [], subscriptions: [] }, null, 2));
const read = () => JSON.parse(fs.readFileSync(DB, 'utf8'));
const write = x => fs.writeFileSync(DB, JSON.stringify(x, null, 2));

const CG = process.env.COINGECKO_API_KEY ? 'https://pro-api.coingecko.com/api/v3' : 'https://api.coingecko.com/api/v3';
async function getJson(url, headers = {}, timeout = 9000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout);
  try {
    const r = await fetch(url, { headers, signal: controller.signal });
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    return await r.json();
  } finally { clearTimeout(timer); }
}
async function cg(ep, p = {}) {
  const u = new URL(CG + ep);
  for (const [k, v] of Object.entries(p)) u.searchParams.set(k, v);
  const h = process.env.COINGECKO_API_KEY ? { 'x-cg-pro-api-key': process.env.COINGECKO_API_KEY } : {};
  return getJson(u, h);
}

function ema(a, p) { if (!a.length) return null; const k = 2 / (p + 1); let e = a[0]; for (let i = 1; i < a.length; i++) e = a[i] * k + e * (1 - k); return e; }
function rsi(a, p = 14) { if (a.length <= p) return 50; let g = 0, l = 0; for (let i = a.length - p; i < a.length; i++) { const d = a[i] - a[i - 1]; if (d >= 0) g += d; else l -= d; } if (!l) return 100; return 100 - 100 / (1 + (g / p) / (l / p)); }

async function marketData() {
  let price = null, change24h = null, marketCap = null, volume = null;
  try {
    const x = await cg('/simple/price', { ids: 'bitcoin', vs_currencies: 'usd', include_24hr_change: 'true', include_market_cap: 'true', include_24hr_vol: 'true' });
    const b = x.bitcoin || {};
    price = b.usd ?? null; change24h = b.usd_24h_change ?? null; marketCap = b.usd_market_cap ?? null; volume = b.usd_24h_vol ?? null;
  } catch {}
  if (price == null) {
    try {
      const x = await getJson('https://api.binance.com/api/v3/ticker/24hr?symbol=BTCUSDT');
      price = Number(x.lastPrice); change24h = Number(x.priceChangePercent); volume = Number(x.quoteVolume);
    } catch {}
  }
  return { price, change24h, marketCap, volume };
}

async function history() {
  try {
    const rows = await getJson('https://api.binance.com/api/v3/klines?symbol=BTCUSDT&interval=15m&limit=96');
    return rows.map(x => Number(x[4]));
  } catch {
    try {
      const x = await cg('/coins/bitcoin/market_chart', { vs_currency: 'usd', days: '1' });
      return (x.prices || []).map(v => Number(v[1]));
    } catch { return []; }
  }
}

async function dominance() {
  try { const x = await cg('/global'); return x?.data?.market_cap_percentage?.btc ?? null; } catch { return null; }
}

async function context() {
  const [m, prices, dom] = await Promise.all([marketData(), history(), dominance()]);
  const a = prices.filter(Number.isFinite);
  const p = m.price ?? a.at(-1) ?? null;
  if (p == null) throw new Error('Impossible de récupérer le prix BTC');
  const e20 = ema(a.length ? a : [p], 20);
  const e50 = ema(a.length ? a : [p], 50);
  const rv = rsi(a.length ? a : [p]);
  const mom = a.length > 12 ? p - a[a.length - 13] : 0;
  return { price: p, change24h: m.change24h, marketCap: m.marketCap, volume: m.volume, dominance: dom, technical: { ema20: e20, ema50: e50, rsi: rv, momentum: mom }, prices: a.slice(-96), at: new Date().toISOString() };
}

app.get('/api/context', async (req, res) => { try { res.json(await context()); } catch (e) { res.status(502).json({ error: e.message }); } });

async function makePrediction(d) {
  if (!process.env.OPENAI_API_KEY) {
    const momentum = Number(d.technical?.momentum || 0);
    const rsiValue = Number(d.technical?.rsi || 50);
    const scenario = momentum > 0 && rsiValue < 70 ? 'HAUSSIER' : momentum < 0 && rsiValue > 30 ? 'BAISSIER' : 'NEUTRE';
    const confidence = Math.round(Math.min(85, 55 + Math.abs(momentum / Math.max(1, d.price)) * 1000 + Math.abs(rsiValue - 50) * 0.25));
    const horizon = s => ({ scenario: s, up: s === 'HAUSSIER' ? 65 : s === 'NEUTRE' ? 30 : 15, neutral: s === 'NEUTRE' ? 40 : 20, down: s === 'BAISSIER' ? 65 : 20 });
    return { scenario, confidence, horizons: { '15m': horizon(scenario), '1h': horizon(scenario), '4h': horizon(scenario) }, reasons: ['Analyse technique locale basée sur momentum, RSI et moyennes mobiles.'], risks: ['Volatilité rapide du Bitcoin.'], invalidation: 'Le scénario doit être réévalué si le momentum s’inverse fortement.' };
  }
  const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
  const prompt = `Tu es LIA, analyste probabiliste BTC. Aucun conseil financier et aucune garantie. Retourne uniquement JSON valide: {"scenario":"HAUSSIER|NEUTRE|BAISSIER","confidence":0,"horizons":{"15m":{"scenario":"HAUSSIER|NEUTRE|BAISSIER","up":0,"neutral":0,"down":0},"1h":{"scenario":"HAUSSIER|NEUTRE|BAISSIER","up":0,"neutral":0,"down":0},"4h":{"scenario":"HAUSSIER|NEUTRE|BAISSIER","up":0,"neutral":0,"down":0}},"reasons":[],"risks":[],"invalidation":""}. Chaque triplet totalise 100. Contexte:${JSON.stringify(d)}`;
  const r = await client.responses.create({ model: process.env.AI_MODEL || 'gpt-5', input: prompt });
  return JSON.parse(r.output_text);
}
app.post('/api/predict', async (req, res) => { try { const d = req.body, p = await makePrediction(d); p.id = crypto.randomUUID(); p.createdAt = new Date().toISOString(); p.referencePrice = d.price; p.status = 'pending'; const db = read(); db.predictions.unshift(p); db.predictions = db.predictions.slice(0, 1000); write(db); res.json(p); } catch (e) { res.status(502).json({ error: e.message }); } });
app.get('/api/predictions', (req, res) => res.json(read().predictions));
function predictedDirection(h) { return h.up >= h.neutral && h.up >= h.down ? 'up' : h.down >= h.neutral && h.down >= h.up ? 'down' : 'neutral'; }
async function evaluate() { const db = read(); if (!db.predictions.length) return; let price; try { price = (await marketData()).price; } catch { return; } if (price == null) return; const now = Date.now(), windows = { '15m': 900000, '1h': 3600000, '4h': 14400000 }; let changed = false; for (const p of db.predictions) { p.results ??= {}; for (const [h, ms] of Object.entries(windows)) { if (p.results[h] || now - new Date(p.createdAt).getTime() < ms) continue; const hd = p.horizons?.[h]; if (!hd || !p.referencePrice) continue; const pct = (price - p.referencePrice) / p.referencePrice * 100; const actual = Math.abs(pct) <= .25 ? 'neutral' : pct > 0 ? 'up' : 'down'; p.results[h] = { predicted: predictedDirection(hd), actual, changePct: pct, correct: predictedDirection(hd) === actual, checkedAt: new Date().toISOString(), price }; changed = true; } p.status = Object.keys(windows).every(h => p.results[h]) ? 'complete' : 'pending'; } if (changed) write(db); }
app.post('/api/evaluate', async (req, res) => { await evaluate(); res.json({ ok: true }); });
app.get('/api/stats', (req, res) => { const db = read(), o = {}; for (const h of ['15m', '1h', '4h']) { const r = db.predictions.flatMap(p => p.results?.[h] ? [p.results[h]] : []), c = r.filter(x => x.correct).length; o[h] = { evaluated: r.length, correct: c, accuracy: r.length ? c / r.length * 100 : null }; } res.json(o); });
app.get('/api/alerts', (req, res) => res.json(read().alerts.slice(0, 50)));
app.post('/api/alerts', (req, res) => { const b = req.body || {}, db = read(); db.alertConfig = { priceUp: b.priceUp ? Number(b.priceUp) : null, priceDown: b.priceDown ? Number(b.priceDown) : null, movePct: Number(b.movePct || 3), enabled: b.enabled !== false, updatedAt: new Date().toISOString() }; write(db); res.json(db.alertConfig); });
app.get('/api/alert-config', (req, res) => res.json(read().alertConfig || { priceUp: null, priceDown: null, movePct: 3, enabled: true }));
async function checkAlerts() { try { const db = read(), cfg = db.alertConfig; if (!cfg?.enabled) return; const d = await context(), last = db.lastPrice; const ev = []; if (cfg.priceUp && d.price >= cfg.priceUp && (!last || last < cfg.priceUp)) ev.push(`BTC a franchi ${cfg.priceUp} $ à la hausse`); if (cfg.priceDown && d.price <= cfg.priceDown && (!last || last > cfg.priceDown)) ev.push(`BTC a franchi ${cfg.priceDown} $ à la baisse`); if (last) { const pct = (d.price - last) / last * 100; if (Math.abs(pct) >= cfg.movePct) ev.push(`Mouvement de ${pct >= 0 ? '+' : ''}${pct.toFixed(2)} % détecté`); } for (const message of ev) db.alerts.unshift({ id: crypto.randomUUID(), message, price: d.price, createdAt: new Date().toISOString() }); db.lastPrice = d.price; db.alerts = db.alerts.slice(0, 200); write(db); } catch {} }
setInterval(async () => { await evaluate(); await checkAlerts(); }, Math.max(5, Number(process.env.POLL_MINUTES || 15)) * 60000);
setTimeout(checkAlerts, 5000);
app.get('/api/push-key', (req, res) => res.json({ publicKey: process.env.VAPID_PUBLIC_KEY || null }));
app.post('/api/push-subscription', (req, res) => { const s = req.body; if (!s?.endpoint) return res.status(400).json({ error: 'subscription invalide' }); const db = read(); db.subscriptions = db.subscriptions.filter(x => x.endpoint !== s.endpoint); db.subscriptions.push(s); db.subscriptions = db.subscriptions.slice(-50); write(db); res.json({ ok: true }); });
app.get('/health', (req, res) => res.json({ ok: true, service: 'btc-radar-lia', version: '1.1', time: new Date().toISOString() }));
app.get('*', (req, res) => res.sendFile(path.join(__dirname, '..', 'public', 'index.html')));
app.listen(process.env.PORT || 3000, () => console.log('BTC Radar LIA 1.1'));
