# BTC Radar LIA — Version finale 1.0

## Les 8 étapes sont regroupées
1. Données de marché
2. Graphique/indicateurs
3. News internationales
4. Moteur LIA
5. Prédictions 15m/1h/4h
6. Vérification et précision
7. Alertes/surveillance
8. Finition: PWA, service worker, santé serveur, séparation des secrets et préparation du déploiement.

## Déploiement
- `npm install`
- copier `.env.example` vers `.env`
- renseigner les clés API
- `npm start`
- mettre le serveur derrière HTTPS pour les notifications Push.

## Important
Le Push iPhone nécessite un contexte HTTPS et des clés VAPID valides. Le package prépare l'architecture mais ne peut pas créer un certificat TLS ni des clés VAPID sans environnement d'hébergement. Les clés privées ne doivent jamais être placées dans le navigateur.
