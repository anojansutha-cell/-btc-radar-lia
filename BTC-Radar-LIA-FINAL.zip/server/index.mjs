import 'dotenv/config';
import express from 'express';
import path from 'node:path';
import fs from 'node:fs';
import {fileURLToPath} from 'node:url';
import OpenAI from 'openai';

const __dirname=path.dirname(fileURLToPath(import.meta.url)), app=express();
app.use(express.json({limit:'100kb'}));
app.use(express.static(path.join(__dirname,'..','public')));
const DB=path.resolve(__dirname,'..',process.env.DB_FILE||'./data/db.json');
fs.mkdirSync(path.dirname(DB),{recursive:true});
if(!fs.existsSync(DB))fs.writeFileSync(DB,JSON.stringify({predictions:[],alerts:[],subscriptions:[]},null,2));
const read=()=>JSON.parse(fs.readFileSync(DB,'utf8'));
const write=x=>fs.writeFileSync(DB,JSON.stringify(x,null,2));

const CG=process.env.COINGECKO_API_KEY?'https://pro-api.coingecko.com/api/v3':'https://api.coingecko.com/api/v3';
async function cg(ep,p={}){const u=new URL(CG+ep);for(const[k,v]of Object.entries(p))u.searchParams.set(k,v);const h={};if(process.env.COINGECKO_API_KEY)h['x-cg-pro-api-key']=process.env.COINGECKO_API_KEY;const r=await fetch(u,{headers:h});if(!r.ok)throw Error('CoinGecko '+r.status);return r.json()}
function ema(a,p){let k=2/(p+1),e=a[0];for(let i=1;i<a.length;i++)e=a[i]*k+e*(1-k);return e}
function rsi(a,p=14){if(a.length<=p)return 50;let g=0,l=0;for(let i=a.length-p;i<a.length;i++){const d=a[i]-a[i-1];d>=0?g+=d:l-=d}if(!l)return 100;const rs=(g/p)/(l/p);return 100-100/(1+rs)}
async function context(){const[s,c,g]=await Promise.all([cg('/simple/price',{ids:'bitcoin',vs_currencies:'usd',include_24hr_change:'true',include_market_cap:'true',include_24hr_vol:'true'}),cg('/coins/bitcoin/market_chart',{vs_currency:'usd',days:'1'}),cg('/global')]);const a=c.prices.map(x=>x[1]),p=a.at(-1),e20=ema(a,20),e50=ema(a,50),rv=rsi(a),mom=p-a[Math.max(0,a.length-13)];return{price:p,change24h:s.bitcoin.usd_24h_change,marketCap:s.bitcoin.usd_market_cap,volume:s.bitcoin.usd_24h_vol,dominance:g.data.market_cap_percentage.btc,technical:{ema20:e20,ema50:e50,rsi:rv,momentum:mom},at:new Date().toISOString()}}
app.get('/api/context',async(req,res)=>{try{res.json(await context())}catch(e){res.status(502).json({error:e.message})}});

async function makePrediction(d){if(!process.env.OPENAI_API_KEY)throw Error('OPENAI_API_KEY non configurée');const client=new OpenAI({apiKey:process.env.OPENAI_API_KEY});const prompt=`Tu es LIA, analyste probabiliste BTC. Ne donne jamais de garantie et aucun ordre d'achat/vente. Retourne uniquement JSON valide: {"scenario":"HAUSSIER|NEUTRE|BAISSIER","confidence":0,"horizons":{"15m":{"scenario":"HAUSSIER|NEUTRE|BAISSIER","up":0,"neutral":0,"down":0},"1h":{"scenario":"HAUSSIER|NEUTRE|BAISSIER","up":0,"neutral":0,"down":0},"4h":{"scenario":"HAUSSIER|NEUTRE|BAISSIER","up":0,"neutral":0,"down":0}},"reasons":[],"risks":[],"invalidation":""}. Chaque triplet doit totaliser 100. Contexte:${JSON.stringify(d)}`;const r=await client.responses.create({model:process.env.AI_MODEL||'gpt-5',input:prompt});return JSON.parse(r.output_text)}
app.post('/api/predict',async(req,res)=>{try{const d=req.body,p=await makePrediction(d);p.id=crypto.randomUUID();p.createdAt=new Date().toISOString();p.referencePrice=d.price;p.status='pending';const db=read();db.predictions.unshift(p);db.predictions=db.predictions.slice(0,1000);write(db);res.json(p)}catch(e){res.status(502).json({error:e.message})}});
app.get('/api/predictions',(req,res)=>res.json(read().predictions));

function predictedDirection(h){return h.up>=h.neutral&&h.up>=h.down?'up':h.down>=h.neutral&&h.down>=h.up?'down':'neutral'}
async function evaluate(){const db=read();if(!db.predictions.length)return;let price;try{price=(await cg('/simple/price',{ids:'bitcoin',vs_currencies:'usd'})).bitcoin.usd}catch{return}
const now=Date.now(), windows={'15m':900000,'1h':3600000,'4h':14400000};let changed=false;
for(const p of db.predictions){p.results??={};for(const[h,ms]of Object.entries(windows)){if(p.results[h]||now-new Date(p.createdAt).getTime()<ms)continue;const hdata=p.horizons?.[h];if(!hdata||!p.referencePrice)continue;const pct=(price-p.referencePrice)/p.referencePrice*100;const actual=Math.abs(pct)<=.25?'neutral':pct>0?'up':'down';p.results[h]={predicted:predictedDirection(hdata),actual,changePct:pct,correct:predictedDirection(hdata)===actual,checkedAt:new Date().toISOString(),price};changed=true}p.status=Object.keys(windows).every(h=>p.results[h])?'complete':'pending'}if(changed)write(db)}
app.post('/api/evaluate',async(req,res)=>{await evaluate();res.json({ok:true})});
app.get('/api/stats',(req,res)=>{const db=read(),o={};for(const h of ['15m','1h','4h']){const r=db.predictions.flatMap(p=>p.results?.[h]?[p.results[h]]:[]),c=r.filter(x=>x.correct).length;o[h]={evaluated:r.length,correct:c,accuracy:r.length?c/r.length*100:null}}res.json(o)});

app.get('/api/alerts',(req,res)=>res.json(read().alerts.slice(0,50)));
app.post('/api/alerts',(req,res)=>{const b=req.body||{},db=read();db.alertConfig={priceUp:b.priceUp?Number(b.priceUp):null,priceDown:b.priceDown?Number(b.priceDown):null,movePct:Number(b.movePct||3),enabled:b.enabled!==false,updatedAt:new Date().toISOString()};write(db);res.json(db.alertConfig)});
app.get('/api/alert-config',(req,res)=>res.json(read().alertConfig||{priceUp:null,priceDown:null,movePct:3,enabled:true}));
async function checkAlerts(){try{const db=read(),cfg=db.alertConfig;if(!cfg?.enabled)return;const d=await context(),last=db.lastPrice;let ev=[];if(cfg.priceUp&&d.price>=cfg.priceUp&&(!last||last<cfg.priceUp))ev.push(`BTC a franchi ${cfg.priceUp} $ à la hausse`);if(cfg.priceDown&&d.price<=cfg.priceDown&&(!last||last>cfg.priceDown))ev.push(`BTC a franchi ${cfg.priceDown} $ à la baisse`);if(last){const pct=(d.price-last)/last*100;if(Math.abs(pct)>=cfg.movePct)ev.push(`Mouvement de ${pct>=0?'+':''}${pct.toFixed(2)} % détecté`)}for(const message of ev)db.alerts.unshift({id:crypto.randomUUID(),message,price:d.price,createdAt:new Date().toISOString()});db.lastPrice=d.price;db.alerts=db.alerts.slice(0,200);write(db)}catch{}}
setInterval(async()=>{await evaluate();await checkAlerts()},Math.max(5,Number(process.env.POLL_MINUTES||15))*60000);
setTimeout(checkAlerts,5000);

app.get('/api/push-key',(req,res)=>res.json({publicKey:process.env.VAPID_PUBLIC_KEY||null}));
app.post('/api/push-subscription',(req,res)=>{const s=req.body;if(!s?.endpoint)return res.status(400).json({error:'subscription invalide'});const db=read();db.subscriptions=db.subscriptions.filter(x=>x.endpoint!==s.endpoint);db.subscriptions.push(s);db.subscriptions=db.subscriptions.slice(-50);write(db);res.json({ok:true})});

app.get('/health',(req,res)=>res.json({ok:true,service:'btc-radar-lia',version:'1.0.0',time:new Date().toISOString()}));
app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'..','public','index.html')));
app.listen(process.env.PORT||3000,()=>console.log('BTC Radar LIA 1.0'));
